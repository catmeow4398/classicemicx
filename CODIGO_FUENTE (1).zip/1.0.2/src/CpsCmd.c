#include "Core.h"
#include "String_.h"
#include "Chat.h"
#include "Commands.h"
#include "Event.h"
#include "Game.h"
#include "Input.h"
#include "Options.h"
#include "World.h"

#define CPS_MAX 64
static double cps_times[CPS_MAX];
static int cps_head, cps_count, cps_last = -1;
static cc_bool cps_task;

static void Cps_Down(void* obj, int key, cc_bool repeating, struct InputDevice* device) {
	if (repeating || key != CCMOUSE_L) return;
	cps_times[cps_head] = Game.Time;
	cps_head = (cps_head + 1) % CPS_MAX;
	if (cps_count < CPS_MAX) cps_count++;
}

static void Cps_Tick(struct ScheduledTask* task) {
	cc_string msg; char buf[STRING_SIZE];
	int i, idx, cps = 0;

	if (!Options_GetBool("cps-counter", false)) {
		if (cps_last != -1) { Chat_AddOf(&String_Empty, MSG_TYPE_CLIENTSTATUS_2); cps_last = -1; }
		return;
	}
	for (i = 0; i < cps_count; i++) {
		idx = (cps_head - 1 - i + CPS_MAX * 2) % CPS_MAX;
		if (Game.Time - cps_times[idx] <= 1.0) cps++;
	}
	if (cps == cps_last) return;
	cps_last = cps;

	String_InitArray(msg, buf);
	String_Format1(&msg, "&eCPS: &f%i", &cps);
	Chat_AddOf(&msg, MSG_TYPE_CLIENTSTATUS_2);
}

static void Cps_EnsureTask(void) {
	if (cps_task) return;
	cps_task = true;
	ScheduledTask_Add(0.25, Cps_Tick);
}

static void Cps_MapLoaded(void* obj) {
	if (Options_GetBool("cps-counter", false)) Cps_EnsureTask();
}

static void CpsCmd_Execute(const cc_string* args, int argsCount) {
	cc_bool on = !Options_GetBool("cps-counter", false);
	Options_SetBool("cps-counter", on);
	Cps_EnsureTask();
	Chat_AddRaw(on ? "&eContador de CPS: &aACTIVADO" : "&eContador de CPS: &cDESACTIVADO");
}

static struct ChatCommand CpsCommand = {
	"CPS", CpsCmd_Execute, COMMAND_FLAG_UNSPLIT_ARGS,
	{
		"&a/client cps",
		"&eActiva o desactiva el contador de clics por segundo."
	}
};

void CpsCmd_Register(void) {
	Event_Register_(&InputEvents.Down2, NULL, Cps_Down);
	Event_Register_(&WorldEvents.MapLoaded, NULL, Cps_MapLoaded);
	Commands_Register(&CpsCommand);
}
